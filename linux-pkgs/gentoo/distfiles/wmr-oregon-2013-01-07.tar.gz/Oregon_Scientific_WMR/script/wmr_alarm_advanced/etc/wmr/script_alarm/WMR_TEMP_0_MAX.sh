#!/bin/sh

echo $1

#
# Power OFF port 2 triger C2000-CP1
# /usr/bin/php5 /etc/wmr/C2000-CP1.php -p 2 -s 0
# /usr/bin/wmr_sendms_sms.ru.sh "Alarm! $1 ... another info ..."
# see doc/C2000CP1controlling4LineRU.pdf
#