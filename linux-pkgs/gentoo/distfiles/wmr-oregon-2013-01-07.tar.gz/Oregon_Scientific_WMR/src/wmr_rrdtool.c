/*
 * Oregon Scientific WMR100/200/WMRS200/I300/I600/RMS600 protocol. Tested on wmrs200.
 *
 * Copyright:
 * 2009 Barnaby Gray <barnaby@pickle.me.uk>
 * 2012-2013 Den68 <idg68@yandex.ru>
 * Latest download URL: http://www.nkl.ru/support/wmr/
 * Global download URL: http://code.google.com/p/wmr/
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/time.h> 
#define GENERAL_RRD 1
#define GENERAL_TABLES 1
#include "wmr_ext.h"
//
#include "rrdupdate/rrd_format.h"
#include "rrdupdate/rrd_generic.h"
#include "rrdupdate/rrd_update.h"

void rrd_update_int( char *rrdtool_exec_path, char *rrdtool_save_path, int table, int sensor, double *updates, int n, int * rrdEn, int syslogEn, int debugEn )
{
	char buf[1024];
        struct rrd_db *         rrd;
        struct timeval          now;
        int                     i;

        gettimeofday(&now, NULL);

	sprintf (buf, WMR_RRD_OUT_FILE, rrdtool_save_path, TABLES[table], sensor);
        if (( rrd = rrd_open(buf)) == NULL) 
	{
	    if( debugEn > 0 )
	    {
		// wmr->rrdEn = 0; ???
		sprintf ( err_string, "RRDTOOL INTERNAL: file %s not found, disable update!\n", buf);
		syslog_msg (syslogEn, err_string);
		rrdEn = 0;
		return;
	    }
        }


    	    if (rrd_update(rrd, now, updates, (n + 1)) < 0) 
	    {
		if( debugEn > 0 )
		{
		    sprintf ( err_string, "RRD UPDATE INTERNAL - file: %s update error: %d!\n", buf, errno );
		    syslog_msg (syslogEn, err_string);
		}

    	    } else {

		if( debugEn > 3 )
		{
    		    for(i = 0; i <= n; i++)
		    {
			sprintf ( err_string, "RRD UPDATE INTERNAL - num: %d cur: %d value: %f\n", n, i, updates[i] );
			syslog_msg (syslogEn, err_string);
		    }
		}

		if( debugEn > 2 )
		{
		    sprintf ( err_string, "RRD UPDATE INTERNAL - file: %s update: %d\n", buf, (n + 1) );
		    syslog_msg (syslogEn, err_string);
		}

	    }


        rrd_close(rrd);

return;
}

void rrdtool_exec ( char *rrdtool_exec_path, char *rrdtool_save_path, int table, int sensor, char *msg, int * rrdEn, int syslogEn, int debugEn )
{
FILE *fd1, *fd2;
char buf[1024];


    if( debugEn > 2 )
    {
	sprintf ( err_string, "RRDTOOL: for (%s) sensor:(%d)\n", TABLES[table], sensor);
	syslog_msg (syslogEn, err_string);
    }

    if (!(fd1 = fopen(rrdtool_exec_path, "r"))) 
    {
	if( debugEn > 0 )
	{
	    sprintf ( err_string, "rrdtool executable not found in path: (%s)\nno RRD graphical created & update", rrdtool_exec_path);
	    syslog_msg (syslogEn, err_string);
	}

	rrdEn = 0;
	return;

    }
    fclose (fd1);


    sprintf (buf, WMR_RRD_OUT_FILE, rrdtool_save_path, TABLES[table], sensor);
		
    if (!(fd2 = fopen(buf, "r")))
    {
	if( debugEn > 1 )
	{
	    sprintf ( err_string, "RRDTOOL: file %s not found, Create!\n", buf);
	    syslog_msg (syslogEn, err_string);
	}

	sprintf (buf, WMR_RRD_CREATE_PAR[table], rrdtool_exec_path, rrdtool_save_path, TABLES[table], sensor, WMR_RRD_CREATE_BASE);
	if(system (buf) != 0)
	{
	    sprintf ( err_string, "RRDTOOL create: error execute command: (%s)\n", buf);
	    syslog_msg (syslogEn, err_string);
	    return;
	}

    } else {
        fclose (fd2);
    }

	sprintf (buf, WMR_RRD_UPDATE_FILE, rrdtool_exec_path, rrdtool_save_path, TABLES[table], sensor, msg);
	if(system (buf) != 0)
	{
	    sprintf ( err_string, "RRDTOOL update: error execute command: (%s)\n", buf);
	    syslog_msg (syslogEn, err_string);
	} else {
	    if( debugEn > 2 )
	    {
		sprintf ( err_string, "RRDTOOL: exec: %s\n", buf);
		syslog_msg (syslogEn, err_string);
	    }
	}


} 

