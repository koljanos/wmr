#ifndef _RRD_MISC_H_
#define _RRD_MISC_H_

int rrd_convert_ds(char *);
int rrd_convert_cf(char *);

#endif
