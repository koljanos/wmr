#ifndef _RRD_UPDATE_H_
#define _RRD_UPDATE_H_

int rrd_update(struct rrd_db *, struct timeval, double *, int);

#endif
