#define DATA_VERSION "Den68 ASCII/SQL/RRD - building: Wed Dec 26 15:17:01 MSK 2012 "
